var dataModel = require('data-model');


dataModel.getCategoryByName('ps4');